# Breast Cancer Analysis

## OBJECTIVE: 
Classifying the breast cancer using different machine learning approach. 

## Machine Algorithms Used:
1. KNN (1NN and 3NN)
2. Fisher's Linear Discrimination 
3. Linear Discrimination Analysis

## Inference:
Data cleaning and Data exploration has been done to the given dataset. A detailed analysis has been done and results are shown in the report.
